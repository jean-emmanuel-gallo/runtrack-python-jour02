def My_print_hello(name):
    print("Hello" , name)

My_print_hello("World")