langage = 'riendutout'

python = 'python'

javascript = 'javascript'

java = 'java'

reactjs = 'reactjs'


if langage == javascript :
    print("Tu es un développeur web")
elif langage == python : 
    print("Tu es un développeur IA")
elif langage == java :
    print('Tu es un développeur logiciel')
elif langage == reactjs : 
    print('Tu es un développeur mobile')
else :
    print('Un jour, je serai le meilleur')