def GetHello(name) : 
    print("Hello", name)

GetHello("la plateforme")