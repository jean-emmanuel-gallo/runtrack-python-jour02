Add = [5, 5]

Sum = sum(Add)
print(Sum)

