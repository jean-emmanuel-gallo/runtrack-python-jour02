def multiply_values(type,saison):
type = 'lol':