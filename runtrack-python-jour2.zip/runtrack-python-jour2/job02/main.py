def My_print_name(name="Tartampion") : 
    print('Hello', name)

My_print_name("Tartampion")

