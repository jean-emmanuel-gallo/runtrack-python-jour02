number = -12 

if number < 0 :
    print("negatif")
else :
    print("positif")



