def calcule(num1, operator, num2) : 
    print(calcule)

    
num1 = 2
operator = "+"
num2 = 4

result = (num1 + num2)

print(result)